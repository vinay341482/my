﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using NUnit.Framework;

namespace UnitTestProject2.EXCEL_Read
{
    public class ExcelRead_TestCase1
    {
        Excel.Application xlApp;
        Excel.Workbook xlWorkbook;
        Excel.Worksheet xlWorksheet;
        Excel.Range xlRange;
        public string[] ExcelReadMethod()
        {
            xlApp = new Excel.Application();
            xlWorkbook = xlApp.Workbooks.Open("D:/selenium/dummy.xlsx");
            xlWorksheet = xlWorkbook.Worksheets[1];
            xlRange = xlWorksheet.UsedRange;
            int rowCount = xlRange.Rows.Count;
            int colCount = xlRange.Columns.Count;
            string[] str = new string[4];
            int i = 1;
            // Console.WriteLine(rowCount);
            //Console.WriteLine(colCount);
            for (int row = 1; row <= 1; row++)
            {
                for (int col = 1; col <= 2; col++)
                {
                    str[i] = xlRange.Cells[row, col].Value2.ToString();
                    Console.WriteLine(str[i]);
                    i++;
                }

                Console.WriteLine("\n");
            }
           // Console.WriteLine("it came here");
            return str;
        }


    }
}
