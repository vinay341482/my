﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using NUnit.Framework;
namespace UnitTestProject2.EXCEL_Read
{
    class ExclRead_TestCase3
    {
        Excel.Application xlApp;
        Excel.Workbook xlWorkbook;
        Excel.Worksheet xlWorksheet;
        Excel.Range xlRange;


        public string[] ExcelMethodToRead()
        {
            xlApp = new Excel.Application();
            xlWorkbook = xlApp.Workbooks.Open("D:/selenium/dummy2.xlsx");
            xlWorksheet = xlWorkbook.Worksheets[1];
            xlRange = xlWorksheet.UsedRange;
            int rowCount = xlRange.Rows.Count;
            int colCount = xlRange.Columns.Count;
            string[] str = new string[16];
            int i = 1;
            // Console.WriteLine(rowCount);
            //Console.WriteLine(colCount);
            for (int row = 1; row <= 1; row++)
            {
                for (int col = 1; col <= 15; col++)
                {
                    str[i] = xlRange.Cells[row, col].Value2.ToString();
                   // Console.WriteLine(str[i]);
                    i++;
                }
               // Console.WriteLine(i);
                // Console.WriteLine("\n");
            }
            return str;

        }
    }

}

