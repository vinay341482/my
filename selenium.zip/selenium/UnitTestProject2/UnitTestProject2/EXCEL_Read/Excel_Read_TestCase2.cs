﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using NUnit.Framework;


namespace UnitTestProject2.EXCEL_Read
{
  

    public class Excel_Read_TestCase2
    {
        Excel.Application xlApp;
        Excel.Workbook xlWorkbook;
        Excel.Worksheet xlWorksheet;
        Excel.Range xlRange;
       
       
        public string[]  ExcelMethod()
        {
            xlApp = new Excel.Application();
            xlWorkbook = xlApp.Workbooks.Open("D:/selenium/Dummy1.xlsx");
            xlWorksheet = xlWorkbook.Worksheets[1];
            xlRange = xlWorksheet.UsedRange;
            int rowCount = xlRange.Rows.Count;
            int colCount = xlRange.Columns.Count;
            string[] str = new string[4];
            int i = 1;
            // Console.WriteLine(rowCount);
            //Console.WriteLine(colCount);
            for (int row = 2; row <= 2; row++)
            {
                for (int col = 1; col <= 3; col++)
                {
                    str[i] = xlRange.Cells[row, col].Value2.ToString();
                    Console.WriteLine(str[i]);
                    i++;
                }

                // Console.WriteLine("\n");
            }
            return str;

        }
    }
}
