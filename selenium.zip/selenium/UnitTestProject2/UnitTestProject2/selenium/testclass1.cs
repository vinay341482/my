﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Configuration;
using System.Collections.ObjectModel;
using OpenQA.Selenium.Support.PageObjects;
using Excel = Microsoft.Office.Interop.Excel;

namespace UnitTestProject2.selenium
{
    public class testclass1
    {
        IWebDriver driver;
        
               
        public testclass1(IWebDriver driver)
        {
            this.driver = driver;
            //for initializing the Page ELements you need to use
            //PageFacgtory.initElements
            PageFactory.InitElements(driver, this);
            
        }
        [FindsBy(How = How.LinkText, Using = "SIGN-ON")]
        private IWebElement SignOn;
        public void verifyHomepage()
        {
            string actualTitle = driver.Title;
                // Console.WriteLine(actualTitle);
                //String expectedTitle = "Welcome: Mercury Tours";
                try
                {
                    actualTitle.Equals("Welcome: Mercury Tours");
                    Console.WriteLine(" HomePage Title Verified");
                }
           
                catch(Exception e)
                {
                    Console.WriteLine("Title didn't match");
                }
                SignOn.Click();

                
            }
        
       

        public void verifySignOnPage()
        {
            string ActualTitle = driver.Title;
            Console.WriteLine(ActualTitle);

            try
            {
                ActualTitle.Equals("Sign-on: Mercury Tours");
                Console.WriteLine("sign-on page Title Matched And Verified");
            }
            catch(Exception e) {
                Console.WriteLine("sign-on page Title didn't match And Verification failed");
            }

            try
            {
                IWebElement link = driver.FindElement(By.LinkText("REGISTER"));
                Console.WriteLine("Registration link is available ");
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Registeration link not found");
            }

            try
            {
                IWebElement header = driver.FindElement(By.XPath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table"));
                Console.WriteLine("header is displaying");
            }
            catch (NoSuchElementException e)
            {
                //Console.WriteLine(e.Message);
                Console.WriteLine("header is not displaying");
            }



        }

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[1]/td[2]/input")]
        private IWebElement usernameBox;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[2]/td[2]/input")]
        private IWebElement paswrdbox;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[4]/td/input")]
        private IWebElement submitbutton;

       


        public void EnterDetails(String username, String paswrd)
        {
           // Console.WriteLine(username);
            usernameBox.Clear();
            usernameBox.SendKeys(username);

            paswrdbox.Clear();
            paswrdbox.SendKeys(paswrd);

            submitbutton.Click();
            

            System.Threading.Thread.Sleep(5000);
            // Console.WriteLine("closing the browser");
            driver.Close(); //Closes the current active browser



        }
    }
}
