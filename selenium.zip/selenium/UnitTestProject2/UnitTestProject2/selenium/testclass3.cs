﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Configuration;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;
using OpenQA.Selenium.Support.PageObjects;

namespace UnitTestProject2.selenium
{
   
    public class testclass3
    {
       
            IWebDriver driver;
            public testclass3(IWebDriver driver)
            {
                this.driver = driver;
                //for initializing the Page ELements you need to use
                //PageFacgtory.initElements
                PageFactory.InitElements(driver, this);
            }

        [FindsBy(How = How.LinkText, Using = "REGISTER")]
        private IWebElement Reg;
        public void verifyHomepage()
        {
            string actualTitle = driver.Title;
            // Console.WriteLine(actualTitle);
            //String expectedTitle = "Welcome: Mercury Tours";
            try
            {
                actualTitle.Equals("Welcome: Mercury Tours");
                Console.WriteLine(" HomePage Title Verified");
            }

            catch (Exception e)
            {
                Console.WriteLine("Title didn't match");
            }
            Reg.Click();
        }

        [FindsBy(How = How.XPath, Using = "//*[@id='email']")]
        private IWebElement usernameBox;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[15]/td[2]/input")]
        private IWebElement paswrdbox;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[16]/td[2]/input")]
        private IWebElement Confrmpaswrdbox;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[18]/td/input")]
        private IWebElement submitbutton;

        [FindsBy(How = How.LinkText, Using = "Flights")]
        public IWebElement flight;

        public void senddetails(string[] str)
        {
            Console.WriteLine(str[3]);
            
            usernameBox.SendKeys(str[1]);
            paswrdbox.SendKeys(str[2]);
            Confrmpaswrdbox.SendKeys(str[3]);
            submitbutton.Click();
        }
        public void clickFlight()
        {
           
           flight.Click();
        }

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[3]/td[2]/b/select")]
        private IWebElement passengers;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[4]/td[2]/select")]
        private IWebElement departingFrom;
        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[5]/td[2]/select[1]")]
        private IWebElement OnMonth;
        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[5]/td[2]/select[2]")]
        private IWebElement OnDate;
        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[6]/td[2]/select")]
        private IWebElement ArrivingIn;
        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[7]/td[2]/select[1]")]
        private IWebElement returningOn;
        //[FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[3]/td[2]/b/select")]
        //private IWebElement Class;
        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[10]/td[2]/select")]
        private IWebElement Airline;
        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[14]/td/input")]
        private IWebElement ContinueButton;

        public void Flight(string[] str)
        {
            SelectElement select = new SelectElement(passengers);
            select.SelectByValue(str[4]);
            SelectElement select1 = new SelectElement(departingFrom);
            select1.SelectByValue(str[5]);
            SelectElement select2 = new SelectElement(OnMonth);
            select2.SelectByValue(str[6]);
            SelectElement select3= new SelectElement(OnDate);
            select3.SelectByValue(str[7]);
            SelectElement select4 = new SelectElement(ArrivingIn);
            select4.SelectByValue(str[8]);
            SelectElement select5 = new SelectElement(returningOn);
            select5.SelectByValue(str[9]);
            SelectElement select6 = new SelectElement(Airline);
            select6.SelectByText(str[10]);


            ContinueButton.Click();


            }

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/p/input")]
        private IWebElement Continue;

        public void contiuneClick()
        {
            Continue.Click();
        }

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[4]/td/table/tbody/tr[2]/td[1]/input")]
        private IWebElement FrstName;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[4]/td/table/tbody/tr[2]/td[2]/input")]
        private IWebElement LastName;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[5]/td/table/tbody/tr[2]/td[1]/input")]
        private IWebElement P2_FrstName;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[5]/td/table/tbody/tr[2]/td[2]/input")]
        private IWebElement P2_LastName;

        [FindsBy(How = How.Name, Using = "creditnumber")]
        private IWebElement CardNum;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[24]/td/input")]
        private IWebElement SecurePay;

        public void PaymentSection(string[] str )
        {
            FrstName.SendKeys(str[11]);
            LastName.SendKeys(str[12]);
            P2_FrstName.SendKeys(str[13]);
            P2_LastName.SendKeys(str[14]);
            CardNum.SendKeys(str[15]);
            SecurePay.Click();
        }

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr[1]/td[2]/table/tbody/tr[5]/td/table/tbody/tr[1]/td/table/tbody/tr/td[1]/b/font/font/b/font[1]")]
        private IWebElement BookingId;

        public void GetBookingId()
        {
            Console.WriteLine("Your Booking is Successfully Completed");
            Console.WriteLine("Your Booking Id Is :"+ BookingId.Text.Replace("Flight Confirmation #", ""));
        }

  
    }
    }

