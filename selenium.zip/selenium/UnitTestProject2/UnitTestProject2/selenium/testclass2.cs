﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Configuration;
using System.Collections.ObjectModel;
using OpenQA.Selenium.Support.PageObjects;

namespace UnitTestProject2.selenium
{
    [TestFixture]
    public class testclass2
    {
        IWebDriver driver;
        public testclass2(IWebDriver driver)
        {
            this.driver = driver;
            //for initializing the Page ELements you need to use
            //PageFacgtory.initElements
            PageFactory.InitElements(driver, this);
        }
        [FindsBy(How = How.LinkText, Using = "REGISTER")]
        private IWebElement Reg;
        public void verifyHomepage()
        {
            string actualTitle = driver.Title;
            // Console.WriteLine(actualTitle);
            //String expectedTitle = "Welcome: Mercury Tours";
            try
            {
                actualTitle.Equals("Welcome: Mercury Tours");
                Console.WriteLine(" HomePage Title Verified");
            }

            catch (Exception e)
            {
                Console.WriteLine("Title didn't match");
            }
            Reg.Click();
        }

        public void  VerifyRegPage()
        {
            string ActualTitle = driver.Title;
            Console.WriteLine(ActualTitle);
            
            try
            {
                ActualTitle.Equals("Register: Mercury Tours");
                Console.WriteLine("registration page is verified");
            }
            catch (Exception e) {
                Console.WriteLine("registration page is  not seen");
            }
        }

        [FindsBy(How = How.XPath, Using = "//*[@id='email']")]
        private IWebElement usernameBox;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[15]/td[2]/input")]
        private IWebElement paswrdbox;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[16]/td[2]/input")]
        private IWebElement Confrmpaswrdbox;

        [FindsBy(How = How.XPath, Using = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[18]/td/input")]
        private IWebElement submitbutton;

        public void EnterDetails(String username, String paswrd,String CnfrmPswrd)
        {
            // Console.WriteLine(username);
            usernameBox.Clear();
            usernameBox.SendKeys(username);

            paswrdbox.Clear();
            paswrdbox.SendKeys(paswrd);

            Confrmpaswrdbox.Clear();
            Confrmpaswrdbox.SendKeys(CnfrmPswrd);

            submitbutton.Click();

            System.Threading.Thread.Sleep(5000);
            driver.Navigate().Back();
            Console.WriteLine("closing the browser");
            driver.Close(); //Closes the current active browser



        }
    }
}
